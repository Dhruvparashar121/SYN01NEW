const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const configMeta = [
  {
    title:'Start Machine',
    tag:'STEP 1',
    visual:'assets/config-step1-start.svg',
    desc:'Boot the Kali-style client in isolated training mode before any routing is applied.',
    cfg:`# STEP 1: Start Client Machine\nMACHINE_NAME=KALI-CLIENT\nMODE=TRAINING_SIMULATION\nSTATUS=BOOTED\nLAB_NETWORK=ISOLATED`,
    cmd:`# STEP 1 - Start client machine profile (safe lab simulation)
mkdir -p ~/anonymity-framework-lab
cat > ~/anonymity-framework-lab/step1-start-machine.conf <<'EOF'
MACHINE_NAME=KALI-CLIENT
MODE=TRAINING_SIMULATION
STATUS=BOOTED
LAB_NETWORK=ISOLATED
EOF
echo "[OK] Kali client profile created"
cat ~/anonymity-framework-lab/step1-start-machine.conf`
  },
  {
    title:'Client IP',
    tag:'STEP 2',
    visual:'assets/config-step2-client-ip.svg',
    desc:'Assign or verify the local client identity, interface, DNS, and logging.',
    cfg:`# STEP 2: Client Network Identity\nCLIENT_IP=10.0.30.10\nCLIENT_INTERFACE=eth0\nDNS_SERVER=1.1.1.1\nLOGGING=ENABLED`,
    cmd:`# STEP 2 - Record client IP settings (safe lab simulation)
cat > ~/anonymity-framework-lab/step2-client-ip.conf <<'EOF'
CLIENT_IP=10.0.30.10
CLIENT_INTERFACE=eth0
DNS_SERVER=1.1.1.1
LOGGING=ENABLED
EOF
echo "[INFO] Current interface view:"
ip addr show eth0 2>/dev/null || ip addr
echo "[OK] Client identity settings saved"`
  },
  {
    title:'Firewall Route',
    tag:'STEP 3',
    visual:'assets/config-step3-firewall.svg',
    desc:'Set the default gateway and keep forwarding restricted to the lab network.',
    cfg:`# STEP 3: Firewall / Gateway Route\nDEFAULT_GATEWAY=10.0.30.1\nFIREWALL_POLICY=ALLOW_LAB_TRAFFIC_ONLY\nBLOCK_EXTERNAL_UNTRUSTED=true`,
    cmd:`# STEP 3 - Save firewall/gateway route policy (safe lab simulation)
cat > ~/anonymity-framework-lab/step3-firewall-route.conf <<'EOF'
DEFAULT_GATEWAY=10.0.30.1
FIREWALL_POLICY=ALLOW_LAB_TRAFFIC_ONLY
BLOCK_EXTERNAL_UNTRUSTED=true
EOF
echo "[INFO] Route table preview:"
ip route show
echo "[OK] Lab-only gateway policy saved"`
  },
  {
    title:'VPS-1 VPN Relay',
    tag:'STEP 4',
    visual:'assets/config-step4-vps1.svg',
    desc:'Route traffic through the first relay; the visible source changes to the VPS-1 IP.',
    cfg:`# STEP 4: VPS-1 Relay\nVPS1_IP=10.0.10.26\nVPS1_ROLE=VPN_RELAY\nFORWARD_TO=10.0.20.100\nNAT_VISUALIZATION=ENABLED`,
    cmd:`# STEP 4 - Save VPS-1 relay profile (safe lab simulation)
cat > ~/anonymity-framework-lab/step4-vps1-relay.conf <<'EOF'
VPS1_IP=10.0.10.26
VPS1_ROLE=VPN_RELAY
FORWARD_TO=10.0.20.100
NAT_VISUALIZATION=ENABLED
EOF
echo "[OK] VPS-1 relay profile saved"
echo "Observable source after VPN relay: 10.0.10.26"`
  },
  {
    title:'VPS-2 Secondary Relay',
    tag:'STEP 5',
    visual:'assets/config-step5-vps2.svg',
    desc:'Add a second relay layer before Tor-style exit rotation.',
    cfg:`# STEP 5: VPS-2 Relay\nVPS2_IP=10.0.20.100\nVPS2_ROLE=SECONDARY_RELAY\nFORWARD_TO=TOR_GATEWAY\nCHAIN_STATUS=ACTIVE`,
    cmd:`# STEP 5 - Save VPS-2 relay profile (safe lab simulation)
cat > ~/anonymity-framework-lab/step5-vps2-relay.conf <<'EOF'
VPS2_IP=10.0.20.100
VPS2_ROLE=SECONDARY_RELAY
FORWARD_TO=TOR_GATEWAY
CHAIN_STATUS=ACTIVE
EOF
echo "[OK] VPS-2 relay profile saved"
echo "Relay chain: CLIENT -> FIREWALL -> VPS1 -> VPS2"`
  },
  {
    title:'Tor Gateway',
    tag:'STEP 6',
    visual:'assets/config-step6-tor.svg',
    desc:'Enable simulated Tor routing; blue team sees rotating exit-node source IPs.',
    cfg:`# STEP 6: Tor Gateway\nTOR_STATUS=ENABLED\nTOR_SOCKS_PORT=9050\nTOR_DNS_PORT=5353\nEXIT_POLICY=LAB_ONLY\nROTATE_EXIT_NODES=true`,
    cmd:`# STEP 6 - Save Tor gateway profile (safe lab simulation)
cat > ~/anonymity-framework-lab/step6-tor-gateway.conf <<'EOF'
TOR_STATUS=ENABLED
TOR_SOCKS_PORT=9050
TOR_DNS_PORT=5353
EXIT_POLICY=LAB_ONLY
ROTATE_EXIT_NODES=true
EOF
echo "[OK] Tor gateway profile saved"
echo "Simulated exit nodes: 10.0.40.10, 10.0.40.20, 10.0.40.30, 10.0.40.40, 10.0.40.50, 10.0.40.60"`,
    tor:true
  }
];

const hints = [
  'Step 1: Start the Kali client machine and verify isolated lab mode.',
  'Step 2: Configure the client IP address, interface, DNS, and logging.',
  'Step 3: Apply the firewall/gateway route for lab-only traffic forwarding.',
  'Step 4: Enable VPS-1 as a VPN-style relay. Observable source becomes 10.0.10.26.',
  'Step 5: Add VPS-2 as the secondary relay before Tor-style routing.',
  'Step 6: Enable simulated Tor gateway and rotating exit-node IP visibility.'
];

const allConfigText = configMeta.map(x => x.cfg).join('\n\n');

const topics = {
  what: `<div class="article"><img class="ai-visual" src="assets/what-framework.svg" alt="AI generated anonymity framework visual"><h3>What is an Anonymity Framework?</h3><p><strong>Basic:</strong> An anonymity framework is a controlled routing model that hides the direct source identity of a client by passing traffic through multiple privacy layers.</p><p><strong>Intermediate:</strong> Instead of allowing a destination host to see the original client directly, traffic is represented as moving through a firewall, relay servers, VPN-like hops, and a Tor-like exit layer.</p><p><strong>Advanced:</strong> In a professional training lab, this framework teaches routing separation, traffic masking, visibility gaps, packet monitoring, source attribution challenges, DNS leakage awareness, and defensive log correlation.</p><div class="article-grid"><div class="info-tile"><h4>Client</h4><p>Origin workstation used by the tester in the isolated lab.</p></div><div class="info-tile"><h4>Relays</h4><p>Intermediate nodes that visually change the observable source path.</p></div><div class="info-tile"><h4>Blue Team</h4><p>Observer role that monitors traffic changes in Wireshark-style logs.</p></div></div></div>`,
  importance: `<div class="article"><img class="ai-visual" src="assets/importance.svg" alt="AI generated importance visual"><h3>Importance of the Framework</h3><p><strong>For ethical hackers:</strong> It teaches how network paths, proxy layers, VPN relays, and Tor-like routing affect source visibility during authorized testing.</p><p><strong>For defenders:</strong> It shows how traffic can look different at each monitoring point, and why packet evidence must be correlated with firewall, endpoint, and gateway logs.</p><p><strong>For students:</strong> It connects theory with visual demonstration: normal traffic, VPN-routed traffic, and Tor-exit traffic can be compared side by side.</p><p><strong>Advanced lesson:</strong> IP masking alone does not guarantee anonymity. Browser fingerprints, timing analysis, DNS leaks, endpoint logs, authentication events, and misconfigured routes can still reveal identity.</p></div>`,
  diagram: 'DIAGRAM_TEMPLATE',
  configs: `<div class="article"><h3>Complete Step-by-Step Configuration Files</h3><p>Each configuration block below maps to the Configuration Module. Every step now includes an animated visual, purpose description, safe prototype configuration, and Kali copy/paste command block.</p><div class="config-file-list">${configMeta.map((s,i)=>`<div class="config-file-box enhanced-step"><div class="step-visual-wrap"><img class="step-visual" src="${s.visual}" alt="Animated visual for ${s.title}"></div><div class="step-copy"><h4>${s.tag}: ${s.title}</h4><p>${s.desc}</p><pre>${s.cfg}</pre><label class="field-label">Kali Linux command box</label><pre class="command-pre">${s.cmd}</pre></div></div>`).join('')}</div></div>`,
  setup: `<div class="article"><img class="ai-visual" src="assets/detailed-setup.svg" alt="AI generated detailed setup visual"><h3>Detailed Setup Flow</h3><ol><li><strong>Start the client:</strong> Boot the Kali-style workstation and ensure it is in isolated lab mode.</li><li><strong>Client to firewall:</strong> Traffic first reaches a firewall/gateway where lab-only rules are applied.</li><li><strong>Firewall to VPS-1:</strong> Approved traffic moves to the first relay. The visible source changes to a VPN-like node.</li><li><strong>VPS-1 to VPS-2:</strong> A second relay adds another separation layer between original client and destination.</li><li><strong>VPS-2 to Tor layer:</strong> Tor-like exit rotation is simulated, showing changing exit-node source IPs.</li><li><strong>Tor to IT network:</strong> The blue-team Windows host observes packet evidence through a Wireshark-style table.</li></ol></div>`
};

let currentStep = 0, currentIP = '10.0.30.10', packetNo = 0, torIndex = 0;
const torIPs = ['10.0.40.10','10.0.40.20','10.0.40.30','10.0.40.40','10.0.40.50','10.0.40.60'];

function setTopic(topic){
  $$('.topic-btn').forEach(b => b.classList.toggle('active', b.dataset.topic === topic));
  $('#topicContent').innerHTML = topic === 'diagram' ? $('#diagramTemplate').innerHTML : topics[topic];
}
function renderConfigCards(){
  $('#configStepCards').innerHTML = configMeta.map((s,i)=>`<div class="config-card ${s.tor?'tor':''}" data-step="${i}"><span class="tag">${s.tag}</span><h4>${s.title}</h4><p>${s.desc}</p></div>`).join('');
  $$('.config-card').forEach(card => card.addEventListener('click', () => loadConfigStep(Number(card.dataset.step))));
}
function terminalLine(target, cmd){const div=document.createElement('div');div.innerHTML=`<span class="prompt">root@kali</span>:~$ ${cmd}`;target.appendChild(div);target.scrollTop=target.scrollHeight}
function systemLine(target, text, cls='ok'){const div=document.createElement('div');div.className=cls;div.textContent=text;target.appendChild(div);target.scrollTop=target.scrollHeight}
function loadConfigStep(step){
  currentStep = step;
  $('#configEditor').value = configMeta[step].cfg;
  if($('#commandEditor')) $('#commandEditor').value = configMeta[step].cmd;
  $('#stepNumber').textContent = `Step ${step+1}`;
  $('#hintText').textContent = hints[step];
  $('#progressBar').style.width = `${((step+1)/configMeta.length)*100}%`;
  $$('.config-card').forEach(c => c.classList.toggle('active', Number(c.dataset.step) === step));
  terminalLine($('#configTerminal'), `load-config --step ${step+1}`);
  systemLine($('#configTerminal'), `Loaded: ${configMeta[step].title}`);
  systemLine($('#configTerminal'), `Kali command box updated for ${configMeta[step].tag}. Copy or run it in this terminal simulation.`, 'warn-text');
}
function applyConfig(){
  const text = $('#configEditor').value.trim();
  if(!text){systemLine($('#configTerminal'),'No configuration found. Paste or type config first.','bad');return;}
  terminalLine($('#configTerminal'),'apply-config --validate --safe-mode');
  systemLine($('#configTerminal'),'Syntax check: OK');
  systemLine($('#configTerminal'),'Simulation state updated. Hint moved to next step.');
  if(currentStep < configMeta.length-1) loadConfigStep(currentStep+1); else systemLine($('#configTerminal'),'All stages completed. Ready for Testing Module.','warn-text');
}
function addPacket(src,dst,proto,info){packetNo++;const tr=document.createElement('tr');tr.className='new-packet';const now=new Date().toLocaleTimeString();const cls=proto.toLowerCase().includes('icmp')?'icmp':proto.toLowerCase().includes('vpn')?'vpn':proto.toLowerCase().includes('tor')?'tor':'tcp';tr.innerHTML=`<td>${packetNo}</td><td>${now}</td><td>${src}</td><td>${dst}</td><td><span class="proto ${cls}">${proto}</span></td><td>${info}</td>`;$('#packetBody').prepend(tr)}
function startPing(){terminalLine($('#kaliTerminal'),'ping 10.0.40.100');let i=0;const timer=setInterval(()=>{i++;addPacket(currentIP,'10.0.40.100','ICMP',`Echo request seq=${i}`);addPacket('10.0.40.100',currentIP,'ICMP',`Echo reply seq=${i}`);if(i>=4)clearInterval(timer)},750)}
function enableVpn(){currentIP='10.0.10.26';terminalLine($('#kaliTerminal'),'vpn --enable --relay VPS-1');systemLine($('#kaliTerminal'),'VPN relay enabled. Observable source changed to VPS-1: 10.0.10.26','warn-text');addPacket(currentIP,'10.0.40.100','VPN','Source changed to VPN relay IP')}
function enableTor(){terminalLine($('#kaliTerminal'),'tor --enable --rotate-exit');let i=0;const timer=setInterval(()=>{currentIP=torIPs[torIndex%torIPs.length];torIndex++;i++;systemLine($('#kaliTerminal'),`Tor exit node selected: ${currentIP}`,'warn-text');addPacket(currentIP,'10.0.40.100','TOR','Simulated rotating Tor exit node');if(i>=6)clearInterval(timer)},900)}
function clearLab(){$('#kaliTerminal').innerHTML='';$('#packetBody').innerHTML='';currentIP='10.0.30.10';packetNo=0;terminalLine($('#kaliTerminal'),'ready');systemLine($('#kaliTerminal'),'Lab reset. Current IP: 10.0.30.10')}


// Real SSH terminal bridge using xterm.js + socket.io.
let sshSocket = null;
let xterm = null;
let sshConnected = false;
function setSshStatus(text, online=false){
  const el = $('#sshStatus');
  if(!el) return;
  el.textContent = text;
  el.className = 'ssh-status ' + (online ? 'online' : 'offline');
}
function initRealTerminal(){
  const target = $('#liveFireTerminal');
  if(!target) return false;
  if(typeof Terminal === 'undefined' || typeof io === 'undefined'){
    setSshStatus('● Start with Node server to enable real SSH terminal', false);
    liveLine('Real SSH terminal unavailable. Run: npm install && npm start', 'warn-text');
    return false;
  }
  if(xterm) return true;
  target.innerHTML = '';
  xterm = new Terminal({
    cursorBlink: true,
    fontFamily: 'Consolas, "Courier New", monospace',
    fontSize: 14,
    theme: { background: '#020617', foreground: '#22c55e', cursor: '#38bdf8' }
  });
  xterm.open(target);
  xterm.writeln('Live Fire SSH Terminal');
  xterm.writeln('Click "Connect SSH Terminal" to open shell on 10.0.30.17');
  xterm.writeln('After connection, click inside this terminal and type commands manually.');
  xterm.writeln('Manual box below is also available for full-line commands.');
  xterm.writeln('');
  xterm.onData(data => {
    if(sshSocket && sshConnected) {
      sshSocket.emit('terminal-input', data);
    } else {
      xterm.write('\r\n[not connected] Click Connect SSH Terminal first.\r\n');
    }
  });
  target.addEventListener('click',()=>xterm.focus());
  return true;
}
function connectSshTerminal(){
  if(!initRealTerminal()) return;
  if(sshSocket && sshConnected){ xterm.writeln('\r\nAlready connected.'); return; }
  setSshStatus('● Connecting to 10.0.30.17...', false);
  xterm.writeln('\r\n[bridge] Connecting to SSH host 10.0.30.17 ...');
  sshSocket = io();
  sshSocket.on('connect', () => sshSocket.emit('ssh-connect'));
  sshSocket.on('ssh-ready', msg => { sshConnected = true; setSshStatus('● SSH connected to 10.0.30.17 — manual input enabled', true); xterm.writeln('\r\n[bridge] ' + msg); xterm.writeln('[bridge] Manual terminal ready. Type commands directly here.'); xterm.focus(); });
  sshSocket.on('terminal-output', data => xterm.write(data));
  sshSocket.on('ssh-error', msg => { sshConnected = false; setSshStatus('● SSH bridge error', false); xterm.writeln('\r\n[error] ' + msg); });
  sshSocket.on('disconnect', () => { sshConnected = false; setSshStatus('● SSH bridge offline', false); if(xterm) xterm.writeln('\r\n[bridge] disconnected'); });
}
function disconnectSshTerminal(){
  if(sshSocket){ sshSocket.emit('ssh-disconnect'); sshSocket.disconnect(); }
  sshConnected = false;
  setSshStatus('● SSH bridge offline', false);
}
function sendToRealTerminal(cmd){
  if(!xterm) initRealTerminal();
  if(sshSocket && sshConnected){
    sshSocket.emit('terminal-input', cmd + '\n');
  } else if(xterm){
    xterm.writeln('[not connected] ' + cmd);
  }
}

function focusManualTerminal(){
  if(initRealTerminal() && xterm){
    xterm.focus();
    xterm.writeln('\r\n[bridge] Focused. Type your command directly in this terminal.');
  }
}
function sendManualCommand(){
  const input = $('#manualCommand');
  if(!input) return;
  const cmd = input.value.trim();
  if(!cmd) return;
  if(!xterm) initRealTerminal();
  if(sshSocket && sshConnected){
    sshSocket.emit('terminal-input', cmd + '\n');
    input.value = '';
    if(xterm) xterm.focus();
  } else if(xterm){
    xterm.writeln('\r\n[not connected] Click Connect SSH Terminal first. Command not sent: ' + cmd);
  }
}
function sendCtrlC(){
  if(sshSocket && sshConnected){
    sshSocket.emit('terminal-input', '\x03');
    if(xterm) xterm.focus();
  } else if(xterm){
    xterm.writeln('\r\n[not connected] Ctrl+C not sent.');
  }
}


const liveFireSteps = {
  host: {
    title: 'STEP 1 - SSH into host machine',
    lines: [
      'sudo ssh superuser@10.0.30.17',
      'password: admin@123',
      '[OK] SSH session established with host machine 10.0.30.17',
      '[INFO] All next actions are launched from this host session.'
    ],
    packet: null
  },
  direct: {
    title: 'STEP 2 - Direct victim test with wg0 down',
    lines: [
      'cd /etc/wireguard && sudo wg-quick down wg0',
      'curl http://10.0.40.100',
      '[WIRESHARK] Direct traffic visible from source IP 10.0.30.17'
    ],
    packet: {src:'10.0.30.17', dst:'10.0.40.100', proto:'HTTP', info:'Direct curl request; wg0 down; source is host machine'}
  },
  vps1: {
    title: 'STEP 3 - Enable VPS-1 route through wg0',
    lines: [
      'cd /etc/wireguard && sudo wg-quick up wg0',
      'ping 10.0.40.100',
      '[WIRESHARK] ICMP traffic now visible from VPS-1 IP 10.0.10.26'
    ],
    packet: {src:'10.0.10.26', dst:'10.0.40.100', proto:'VPN', info:'wg0 up; observable source changed to VPS-1'}
  },
  vps2: {
    title: 'STEP 4 - SSH into VPS-1 and enable wg1 toward VPS-2',
    lines: [
      'sudo ssh book@10.0.10.26',
      'password: MKO)9ijm*765#',
      'cd /etc/wireguard && sudo wg-quick up wg1',
      'curl http://10.0.40.100',
      '[WIRESHARK] Victim-side packets now show VPS-2 IP 10.0.20.102'
    ],
    packet: {src:'10.0.20.102', dst:'10.0.40.100', proto:'VPN', info:'wg1 up via VPS-1; observable source changed to VPS-2'}
  },
  tor: {
    title: 'STEP 5 - SSH into Tor and start SOCKS tunnel',
    lines: [
      'sudo ssh book@10.0.40.102',
      'password: MKO)9ijm*765#',
      'sudo ssh -D 0.0.0.0:1080 administrator@10.0.40.102',
      'curl http://10.0.40.100',
      '[WIRESHARK] Victim-side packets now show Tor IP 10.0.40.102'
    ],
    packet: {src:'10.0.40.102', dst:'10.0.40.100', proto:'TOR', info:'SOCKS tunnel active; observable source changed to Tor node'}
  }
};
function liveLine(text, cls='ok'){
  const target = $('#liveFireTerminal');
  if(!target) return;
  const isCmd = text.startsWith('sudo') || text.startsWith('cd ') || text.startsWith('curl') || text.startsWith('ping');
  const display = isCmd ? `livefire@host:~$ ${text}` : text;
  if(xterm){
    xterm.writeln(display);
    return;
  }
  const div = document.createElement('div');
  if(isCmd){ div.innerHTML = `<span class="prompt">livefire@host</span>:~$ ${text}`; }
  else { div.className = cls; div.textContent = text; }
  target.appendChild(div);
  target.scrollTop = target.scrollHeight;
}
function runLiveFireStep(key){
  const step = liveFireSteps[key];
  if(!step) return;
  liveLine('────────────────────────────────────────', 'warn-text');
  liveLine(step.title, 'warn-text');
  step.lines.forEach((line, idx)=>setTimeout(()=>{ liveLine(line, line.startsWith('[WIRESHARK]') ? 'action-text' : 'ok'); if(key !== 'host' && !line.startsWith('[') && !line.startsWith('password:')) sendToRealTerminal(line); }, idx*260));
  if(step.packet){
    setTimeout(()=>{
      currentIP = step.packet.src;
      addPacket(step.packet.src, step.packet.dst, step.packet.proto, step.packet.info);
      if(step.packet.proto === 'VPN' || step.packet.proto === 'TOR') addPacket(step.packet.dst, step.packet.src, step.packet.proto, 'Victim response to current live-fire route');
    }, step.lines.length*270);
  }
}
function resetLiveFire(){
  const lf = $('#liveFireTerminal');
  if(xterm){ xterm.clear(); }
  else if(lf) lf.innerHTML = '';
  liveLine('ready');
  liveLine('Live Fire reset. Connect SSH terminal, then execute commands manually on 10.0.30.17.','warn-text');
}

async function copyCommand(){
  if(!$('#commandEditor')) return;
  await navigator.clipboard.writeText($('#commandEditor').value);
  systemLine($('#configTerminal'),'Kali command block copied to clipboard. Paste it into your Kali terminal for this lab step.','ok');
}
function runCommandSimulation(){
  if(!$('#commandEditor')) return;
  const lines = $('#commandEditor').value.split('\n').filter(Boolean);
  terminalLine($('#configTerminal'),`execute-step --safe-simulation ${currentStep+1}`);
  lines.slice(0,10).forEach(line => {
    const clean=line.length>96 ? line.slice(0,96)+'…' : line;
    if(clean.trim().startsWith('#')) systemLine($('#configTerminal'),clean.replace(/^#\s*/,''),'warn-text');
    else systemLine($('#configTerminal'),clean,'ok');
  });
  systemLine($('#configTerminal'),`Step ${currentStep+1} command simulation completed successfully.`,'ok');
}

$$('.nav-btn').forEach(btn=>btn.addEventListener('click',()=>{
async function copyCommand(){
  if(!$('#commandEditor')) return;
  await navigator.clipboard.writeText($('#commandEditor').value);
  systemLine($('#configTerminal'),'Kali command block copied to clipboard. Paste it into your Kali terminal for this lab step.','ok');
}
function runCommandSimulation(){
  if(!$('#commandEditor')) return;
  const lines = $('#commandEditor').value.split('\n').filter(Boolean);
  terminalLine($('#configTerminal'),`execute-step --safe-simulation ${currentStep+1}`);
  lines.slice(0,10).forEach(line => {
    const clean=line.length>96 ? line.slice(0,96)+'…' : line;
    if(clean.trim().startsWith('#')) systemLine($('#configTerminal'),clean.replace(/^#\s*/,''),'warn-text');
    else systemLine($('#configTerminal'),clean,'ok');
  });
  systemLine($('#configTerminal'),`Step ${currentStep+1} command simulation completed successfully.`,'ok');
}

$$('.nav-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');$$('.tab-panel').forEach(p=>p.classList.remove('active'));$('#'+btn.dataset.tab).classList.add('active')}));
$$('.topic-btn').forEach(btn=>btn.addEventListener('click',()=>setTopic(btn.dataset.topic)));
$('#applyConfig').addEventListener('click',applyConfig);
$('#copyConfig').addEventListener('click',async()=>{await navigator.clipboard.writeText($('#configEditor').value);systemLine($('#configTerminal'),'Configuration copied to clipboard.','ok')});
if($('#copyCommand')) $('#copyCommand').addEventListener('click',copyCommand);
if($('#runCommand')) $('#runCommand').addEventListener('click',runCommandSimulation);
$('#resetConfig').addEventListener('click',()=>loadConfigStep(0));
$('#startPing').addEventListener('click',startPing);$('#enableVpn').addEventListener('click',enableVpn);$('#enableTor').addEventListener('click',enableTor);$('#clearLab').addEventListener('click',clearLab);
if($('#lfHost')) $('#lfHost').addEventListener('click',()=>runLiveFireStep('host'));
if($('#lfDirect')) $('#lfDirect').addEventListener('click',()=>runLiveFireStep('direct'));
if($('#lfVps1')) $('#lfVps1').addEventListener('click',()=>runLiveFireStep('vps1'));
if($('#lfVps2')) $('#lfVps2').addEventListener('click',()=>runLiveFireStep('vps2'));
if($('#lfTor')) $('#lfTor').addEventListener('click',()=>runLiveFireStep('tor'));
if($('#lfReset')) $('#lfReset').addEventListener('click',resetLiveFire);
if($('#connectSsh')) $('#connectSsh').addEventListener('click',connectSshTerminal);
if($('#focusTerminal')) $('#focusTerminal').addEventListener('click',focusManualTerminal);
if($('#sendManualCommand')) $('#sendManualCommand').addEventListener('click',sendManualCommand);
if($('#manualCommand')) $('#manualCommand').addEventListener('keydown',e=>{if(e.key==='Enter') sendManualCommand();});
if($('#sendCtrlC')) $('#sendCtrlC').addEventListener('click',sendCtrlC);
if($('#disconnectSsh')) $('#disconnectSsh').addEventListener('click',disconnectSshTerminal);

renderConfigCards();setTopic('what');loadConfigStep(0);clearLab();resetLiveFire();initRealTerminal();
