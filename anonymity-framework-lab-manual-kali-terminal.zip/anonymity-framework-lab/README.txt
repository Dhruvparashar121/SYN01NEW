Anonymity Framework Lab - Professional UI Prototype

How to run:
1. Extract the ZIP file.
2. Open index.html in Google Chrome, Edge, or Firefox.

Included:
- Training Module with detailed learning content
- Animated packet-flow diagram
- Kali + Windows split-screen shown only under Diagram
- Configuration Module with guided hints and editable configs
- Testing Module with realistic Kali terminal and Wireshark-style animated packet table

Note:
This is a safe visual simulation for ethical cybersecurity training. It does not perform real attacks, real VPN routing, or real Tor routing.
