const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const { Client } = require('ssh2');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const SSH_HOST = process.env.SSH_HOST || '10.0.30.17';
const SSH_PORT = Number(process.env.SSH_PORT || 22);
const SSH_USER = process.env.SSH_USER || 'superuser';
const SSH_PASSWORD = process.env.SSH_PASSWORD || 'admin@123';

app.use('/xterm', express.static(path.join(__dirname, 'node_modules', '@xterm', 'xterm', 'lib')));
app.use(express.static(__dirname));

io.on('connection', (socket) => {
  let conn = null;
  let shell = null;

  socket.on('ssh-connect', () => {
    if (conn) return;
    conn = new Client();
    conn.on('ready', () => {
      conn.shell({ term: 'xterm-256color', cols: 120, rows: 34 }, (err, stream) => {
        if (err) {
          socket.emit('ssh-error', err.message);
          conn.end();
          conn = null;
          return;
        }
        shell = stream;
        socket.emit('ssh-ready', `Connected as ${SSH_USER}@${SSH_HOST}`);
        stream.on('data', (data) => socket.emit('terminal-output', data.toString('utf8')));
        stream.stderr.on('data', (data) => socket.emit('terminal-output', data.toString('utf8')));
        stream.on('close', () => {
          socket.emit('terminal-output', '\r\n[bridge] SSH shell closed\r\n');
          if (conn) conn.end();
          conn = null;
          shell = null;
        });
      });
    });
    conn.on('error', (err) => socket.emit('ssh-error', err.message));
    conn.on('close', () => { conn = null; shell = null; });
    conn.connect({ host: SSH_HOST, port: SSH_PORT, username: SSH_USER, password: SSH_PASSWORD, readyTimeout: 15000, keepaliveInterval: 10000 });
  });

  socket.on('terminal-input', (data) => {
    if (shell) shell.write(data);
    else socket.emit('ssh-error', 'SSH shell is not connected. Click Connect SSH Terminal first.');
  });

  socket.on('ssh-disconnect', () => {
    if (shell) shell.end('exit\n');
    if (conn) conn.end();
    conn = null;
    shell = null;
  });

  socket.on('disconnect', () => {
    if (shell) shell.end();
    if (conn) conn.end();
  });
});

server.listen(PORT, () => console.log(`Anonymity Framework SSH terminal running: http://localhost:${PORT}`));
